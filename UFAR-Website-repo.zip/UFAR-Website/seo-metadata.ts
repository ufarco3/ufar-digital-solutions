/**
 * UFAR Digital Solutions — SEO & GEO metadata
 * Generated 2026-11-23. One source of truth for titles, descriptions, keywords (EN + AR),
 * canonical URLs, Open Graph / Twitter cards, FAQ content and JSON-LD.
 *
 * Next.js (App Router):  export const metadata = getPageMetadata("/services");
 * Any other stack: read `pages[route]` and render the same tags in <head>.
 */
import type { Metadata } from "next";

export const SITE_URL = "https://ufar-eg.com";

export const site = {
  "name": "UFAR Digital Solutions",
  "shortName": "UFAR",
  "tagline": "United For A Reason",
  "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
  "url": "https://ufar-eg.com",
  "locale": "en_US",
  "alternateLocale": "ar_EG",
  "country": "EG",
  "parentOrganization": "UFAR Group",
  "telephone": "+201146767446",
  "whatsapp": "https://wa.me/201146767446",
  "contactPage": "https://ufar-eg.com/contact.html",
  "themeColor": "#101D35",
  "logo": "https://ufar-eg.com/assets/images/logo.png"
} as const;

export type PageRoute = "/" | "/about" | "/services" | "/positioning-marketing-strategy" | "/brand-identity-design" | "/digital-experiences" | "/content-brand-storytelling" | "/media-production" | "/social-media-community" | "/campaigns-performance" | "/clients" | "/contact";

export interface PageSEO {
  file: string;
  title: string;
  description: string;
  keywords: string[];
  alternates: { canonical: string };
  robots: Metadata["robots"];
  openGraph: NonNullable<Metadata["openGraph"]>;
  twitter: NonNullable<Metadata["twitter"]>;
}

export const pages: Record<PageRoute, PageSEO> = {
  "/": {
    "file": "index.html",
    "title": "UFAR Digital Solutions | Creative & Digital Agency in Egypt",
    "description": "Creative and digital agency in Egypt: marketing strategy, branding, websites, content, video production, social media and paid campaigns. Part of UFAR Group.",
    "keywords": [
      "creative and digital agency Egypt",
      "digital marketing agency Egypt",
      "branding agency Egypt",
      "UFAR Group",
      "شركة تسويق في مصر",
      "وكالة دعاية وإعلان",
      "شركة تسويق رقمي",
      "وكالة ديجيتال ماركتنج",
      "شركة براندينج"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "UFAR Digital Solutions | Creative & Digital Agency in Egypt",
      "description": "Creative and digital agency in Egypt: marketing strategy, branding, websites, content, video production, social media and paid campaigns. Part of UFAR Group.",
      "url": "https://ufar-eg.com/",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-home.jpg",
          "width": 1200,
          "height": 630,
          "alt": "UFAR Digital Solutions — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "UFAR Digital Solutions | Creative & Digital Agency in Egypt",
      "description": "Creative and digital agency in Egypt: marketing strategy, branding, websites, content, video production, social media and paid campaigns. Part of UFAR Group.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-home.jpg"
      ]
    }
  },
  "/about": {
    "file": "about.html",
    "title": "About UFAR Digital Solutions | Part of UFAR Group",
    "description": "Meet UFAR Digital Solutions, the creative and digital agency of UFAR Group in Egypt: our story, vision, mission, brand promise and a word from Mr. Ibrahim.",
    "keywords": [
      "about UFAR Digital Solutions",
      "UFAR Group",
      "marketing agency Egypt",
      "United For A Reason",
      "يوفار",
      "شركة يوفار",
      "مجموعة يوفار",
      "UFAR Group",
      "يوفار للحلول الرقمية"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/about.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "About UFAR Digital Solutions | Part of UFAR Group",
      "description": "Meet UFAR Digital Solutions, the creative and digital agency of UFAR Group in Egypt: our story, vision, mission, brand promise and a word from Mr. Ibrahim.",
      "url": "https://ufar-eg.com/about.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-about.jpg",
          "width": 1200,
          "height": 630,
          "alt": "About UFAR Digital Solutions — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "About UFAR Digital Solutions | Part of UFAR Group",
      "description": "Meet UFAR Digital Solutions, the creative and digital agency of UFAR Group in Egypt: our story, vision, mission, brand promise and a word from Mr. Ibrahim.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-about.jpg"
      ]
    }
  },
  "/services": {
    "file": "services.html",
    "title": "Marketing, Branding & Digital Services in Egypt | UFAR",
    "description": "Seven areas of expertise, one vision: strategy, branding, websites, content, media production, social media and campaigns. UFAR's services in Egypt.",
    "keywords": [
      "marketing and branding services Egypt",
      "digital agency services",
      "full-service agency Egypt",
      "خدمات التسويق الرقمي",
      "خدمات البراندينج",
      "خدمات الدعاية والإعلان",
      "وكالة تسويق متكاملة"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/services.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Marketing, Branding & Digital Services in Egypt | UFAR",
      "description": "Seven areas of expertise, one vision: strategy, branding, websites, content, media production, social media and campaigns. UFAR's services in Egypt.",
      "url": "https://ufar-eg.com/services.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-services.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Marketing, Branding & Digital Services in Egypt — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Marketing, Branding & Digital Services in Egypt | UFAR",
      "description": "Seven areas of expertise, one vision: strategy, branding, websites, content, media production, social media and campaigns. UFAR's services in Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-services.jpg"
      ]
    }
  },
  "/positioning-marketing-strategy": {
    "file": "positioning-marketing-strategy.html",
    "title": "Positioning & Marketing Strategy Agency in Egypt | UFAR",
    "description": "Brand audit, competitor benchmarking, positioning and a 90-day marketing plan in 3–5 weeks. Marketing strategy from UFAR Digital Solutions, Egypt.",
    "keywords": [
      "marketing strategy agency Egypt",
      "brand positioning Egypt",
      "marketing plan",
      "brand audit",
      "competitor analysis",
      "خطة تسويقية",
      "استراتيجية تسويق",
      "تحليل المنافسين",
      "دراسة السوق",
      "تموضع العلامة التجارية"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/positioning-marketing-strategy.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Positioning & Marketing Strategy Agency in Egypt | UFAR",
      "description": "Brand audit, competitor benchmarking, positioning and a 90-day marketing plan in 3–5 weeks. Marketing strategy from UFAR Digital Solutions, Egypt.",
      "url": "https://ufar-eg.com/positioning-marketing-strategy.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-strategy.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Positioning & Marketing Strategy — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Positioning & Marketing Strategy Agency in Egypt | UFAR",
      "description": "Brand audit, competitor benchmarking, positioning and a 90-day marketing plan in 3–5 weeks. Marketing strategy from UFAR Digital Solutions, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-strategy.jpg"
      ]
    }
  },
  "/brand-identity-design": {
    "file": "brand-identity-design.html",
    "title": "Brand Identity & Logo Design Agency in Egypt | UFAR",
    "description": "Logo design, visual identity systems, brand guidelines, company profiles and packaging in 4–6 weeks. Brand identity design by UFAR Digital Solutions, Egypt.",
    "keywords": [
      "brand identity design Egypt",
      "logo design Egypt",
      "branding agency Egypt",
      "brand guidelines",
      "company profile design",
      "تصميم هوية بصرية",
      "تصميم لوجو",
      "تصميم شعار",
      "براندينج",
      "تصميم بروفايل شركة"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/brand-identity-design.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Brand Identity & Logo Design Agency in Egypt | UFAR",
      "description": "Logo design, visual identity systems, brand guidelines, company profiles and packaging in 4–6 weeks. Brand identity design by UFAR Digital Solutions, Egypt.",
      "url": "https://ufar-eg.com/brand-identity-design.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-identity.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Brand Identity & Design — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Brand Identity & Logo Design Agency in Egypt | UFAR",
      "description": "Logo design, visual identity systems, brand guidelines, company profiles and packaging in 4–6 weeks. Brand identity design by UFAR Digital Solutions, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-identity.jpg"
      ]
    }
  },
  "/digital-experiences": {
    "file": "digital-experiences.html",
    "title": "Website Design & Development Company in Egypt | UFAR",
    "description": "Corporate websites, e-commerce stores, landing pages and bilingual Arabic–English sites, designed and built in 4–10 weeks by UFAR Digital Solutions, Egypt.",
    "keywords": [
      "website design company Egypt",
      "web development Egypt",
      "e-commerce website Egypt",
      "UX UI design",
      "Arabic English website",
      "تصميم مواقع",
      "برمجة مواقع",
      "تصميم متجر إلكتروني",
      "تصميم موقع شركة",
      "صفحة هبوط"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/digital-experiences.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Website Design & Development Company in Egypt | UFAR",
      "description": "Corporate websites, e-commerce stores, landing pages and bilingual Arabic–English sites, designed and built in 4–10 weeks by UFAR Digital Solutions, Egypt.",
      "url": "https://ufar-eg.com/digital-experiences.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-digital.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Digital Experiences — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Website Design & Development Company in Egypt | UFAR",
      "description": "Corporate websites, e-commerce stores, landing pages and bilingual Arabic–English sites, designed and built in 4–10 weeks by UFAR Digital Solutions, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-digital.jpg"
      ]
    }
  },
  "/content-brand-storytelling": {
    "file": "content-brand-storytelling.html",
    "title": "Content Writing & Brand Storytelling in Egypt | UFAR",
    "description": "Content strategy, website and company profile copy, scripts and social copy in Arabic and English. Brand storytelling by UFAR Digital Solutions, Egypt.",
    "keywords": [
      "content writing services Egypt",
      "copywriting Arabic English",
      "content strategy",
      "brand storytelling",
      "كتابة محتوى",
      "كتابة محتوى تسويقي",
      "كوبي رايتنج",
      "كتابة سكريبت إعلان",
      "ترجمة تسويقية"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/content-brand-storytelling.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Content Writing & Brand Storytelling in Egypt | UFAR",
      "description": "Content strategy, website and company profile copy, scripts and social copy in Arabic and English. Brand storytelling by UFAR Digital Solutions, Egypt.",
      "url": "https://ufar-eg.com/content-brand-storytelling.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-content.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Content & Brand Storytelling — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Content Writing & Brand Storytelling in Egypt | UFAR",
      "description": "Content strategy, website and company profile copy, scripts and social copy in Arabic and English. Brand storytelling by UFAR Digital Solutions, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-content.jpg"
      ]
    }
  },
  "/media-production": {
    "file": "media-production.html",
    "title": "Video Production & Photography Company in Egypt | UFAR",
    "description": "Brand films, commercials, event coverage, reels, product and architecture photography, editing and motion graphics. Media production by UFAR, Egypt.",
    "keywords": [
      "video production company Egypt",
      "corporate video Egypt",
      "photography Egypt",
      "motion graphics",
      "commercial production",
      "شركة إنتاج فيديو",
      "تصوير إعلانات",
      "تصوير منتجات",
      "فيديو تعريفي للشركات",
      "موشن جرافيك"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/media-production.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Video Production & Photography Company in Egypt | UFAR",
      "description": "Brand films, commercials, event coverage, reels, product and architecture photography, editing and motion graphics. Media production by UFAR, Egypt.",
      "url": "https://ufar-eg.com/media-production.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-media.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Media Production — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Video Production & Photography Company in Egypt | UFAR",
      "description": "Brand films, commercials, event coverage, reels, product and architecture photography, editing and motion graphics. Media production by UFAR, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-media.jpg"
      ]
    }
  },
  "/social-media-community": {
    "file": "social-media-community.html",
    "title": "Social Media Management Agency in Egypt | UFAR",
    "description": "Social media strategy, content calendars, designed posts, reels, moderation, community management and monthly reports. Social media management by UFAR, Egypt.",
    "keywords": [
      "social media management Egypt",
      "social media agency Egypt",
      "community management",
      "content calendar",
      "إدارة صفحات السوشيال ميديا",
      "إدارة حسابات التواصل الاجتماعي",
      "تصميم بوستات",
      "كوميونيتي مانجمنت"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/social-media-community.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Social Media Management Agency in Egypt | UFAR",
      "description": "Social media strategy, content calendars, designed posts, reels, moderation, community management and monthly reports. Social media management by UFAR, Egypt.",
      "url": "https://ufar-eg.com/social-media-community.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-social.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Social Media & Community — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Social Media Management Agency in Egypt | UFAR",
      "description": "Social media strategy, content calendars, designed posts, reels, moderation, community management and monthly reports. Social media management by UFAR, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-social.jpg"
      ]
    }
  },
  "/campaigns-performance": {
    "file": "campaigns-performance.html",
    "title": "Performance Marketing & Paid Ads Agency in Egypt | UFAR",
    "description": "Media planning, tracking, paid campaigns on Meta, Google, TikTok and LinkedIn, plus SEO, managed against agreed goals. Performance marketing by UFAR, Egypt.",
    "keywords": [
      "performance marketing agency Egypt",
      "paid ads management Egypt",
      "media buying Egypt",
      "Google Ads",
      "Meta Ads",
      "SEO Egypt",
      "إدارة الإعلانات الممولة",
      "حملات إعلانية",
      "ميديا باينج",
      "إعلانات فيسبوك وجوجل",
      "تحسين محركات البحث SEO"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/campaigns-performance.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Performance Marketing & Paid Ads Agency in Egypt | UFAR",
      "description": "Media planning, tracking, paid campaigns on Meta, Google, TikTok and LinkedIn, plus SEO, managed against agreed goals. Performance marketing by UFAR, Egypt.",
      "url": "https://ufar-eg.com/campaigns-performance.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-campaigns.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Campaigns & Performance — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Performance Marketing & Paid Ads Agency in Egypt | UFAR",
      "description": "Media planning, tracking, paid campaigns on Meta, Google, TikTok and LinkedIn, plus SEO, managed against agreed goals. Performance marketing by UFAR, Egypt.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-campaigns.jpg"
      ]
    }
  },
  "/clients": {
    "file": "clients.html",
    "title": "Our Clients | UFAR Digital Solutions",
    "description": "Brands that work with UFAR Digital Solutions, including Kempinski, Vodafone, Banque Misr, Ezz Elarab Automotive Group, Resala and UFAR Group companies.",
    "keywords": [
      "UFAR clients",
      "agency portfolio Egypt",
      "Kempinski",
      "Vodafone",
      "Banque Misr",
      "عملاء يوفار",
      "أعمال شركة تسويق",
      "سابقة أعمال"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/clients.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Our Clients | UFAR Digital Solutions",
      "description": "Brands that work with UFAR Digital Solutions, including Kempinski, Vodafone, Banque Misr, Ezz Elarab Automotive Group, Resala and UFAR Group companies.",
      "url": "https://ufar-eg.com/clients.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-clients.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Our Clients — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Our Clients | UFAR Digital Solutions",
      "description": "Brands that work with UFAR Digital Solutions, including Kempinski, Vodafone, Banque Misr, Ezz Elarab Automotive Group, Resala and UFAR Group companies.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-clients.jpg"
      ]
    }
  },
  "/contact": {
    "file": "contact.html",
    "title": "Contact UFAR Digital Solutions | Start a Project",
    "description": "Tell us what you are building. Use the contact form or WhatsApp +20 114 676 7446 — we reply within two working days with the questions that shape the brief.",
    "keywords": [
      "contact UFAR Digital Solutions",
      "request a proposal",
      "marketing agency contact Egypt",
      "تواصل مع شركة تسويق",
      "طلب عرض سعر تسويق",
      "شركة دعاية وإعلان مصر"
    ],
    "alternates": {
      "canonical": "https://ufar-eg.com/contact.html"
    },
    "robots": {
      "index": true,
      "follow": true,
      "googleBot": {
        "index": true,
        "follow": true,
        "max-image-preview": "large",
        "max-snippet": -1
      }
    },
    "openGraph": {
      "type": "website",
      "siteName": "UFAR Digital Solutions",
      "locale": "en_US",
      "alternateLocale": [
        "ar_EG"
      ],
      "title": "Contact UFAR Digital Solutions | Start a Project",
      "description": "Tell us what you are building. Use the contact form or WhatsApp +20 114 676 7446 — we reply within two working days with the questions that shape the brief.",
      "url": "https://ufar-eg.com/contact.html",
      "images": [
        {
          "url": "https://ufar-eg.com/assets/images/og/og-contact.jpg",
          "width": 1200,
          "height": 630,
          "alt": "Contact UFAR Digital Solutions — UFAR Digital Solutions"
        }
      ]
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Contact UFAR Digital Solutions | Start a Project",
      "description": "Tell us what you are building. Use the contact form or WhatsApp +20 114 676 7446 — we reply within two working days with the questions that shape the brief.",
      "images": [
        "https://ufar-eg.com/assets/images/og/og-contact.jpg"
      ]
    }
  }
};

export interface FAQItem { question: string; answer: string }

export const faqs: Partial<Record<PageRoute, FAQItem[]>> = {
  "/": [
    {
      "question": "What is UFAR Digital Solutions?",
      "answer": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals."
    },
    {
      "question": "Where is UFAR Digital Solutions based?",
      "answer": "UFAR Digital Solutions works from Egypt and is part of UFAR Group, alongside UFAR Real Estate Developments and UFAR Petroleum Services."
    },
    {
      "question": "What services does UFAR offer?",
      "answer": "Seven services: Positioning & Marketing Strategy, Brand Identity & Design, Digital Experiences (websites), Content & Brand Storytelling, Media Production, Social Media & Community, and Campaigns & Performance. Each can be used on its own or together."
    },
    {
      "question": "How does UFAR price its work?",
      "answer": "Every proposal is priced line by line, with no fixed packages, so you only pay for the work your business needs. Media production is quoted per project once we receive your brief."
    },
    {
      "question": "How do I start a project with UFAR?",
      "answer": "Send a message through the contact page or on WhatsApp +20 114 676 7446. We reply within two working days, agree the brief on a short call, then send a proposal."
    }
  ],
  "/positioning-marketing-strategy": [
    {
      "question": "What does Positioning & Marketing Strategy include?",
      "answer": "A brand experience audit of up to five touchpoints, benchmarking against three to five competitors, audience profiles and buying journey, positioning and value proposition, brand story and key messages, a marketing strategy with channels, priorities and KPIs, a 90-day action plan, and a strategy workshop with a final presentation."
    },
    {
      "question": "How long does a marketing strategy take?",
      "answer": "Typically 3–5 weeks, in five stages: kick-off and audit, benchmarking, audience definition, positioning, and the final strategy with a 90-day action plan."
    },
    {
      "question": "Who is this service for?",
      "answer": "Businesses launching something new, established brands that need a clearer direction, and companies preparing for growth. It is also the recommended starting point if you are not sure which service you need."
    },
    {
      "question": "How is the strategy priced?",
      "answer": "It is priced as one complete service rather than separate items. Contact us for a proposal based on your business and scope."
    }
  ],
  "/brand-identity-design": [
    {
      "question": "What does brand identity design include?",
      "answer": "Logo development, a visual identity system (colour, typography, graphic language), brand guidelines, stationery, company profiles, sales presentations, packaging and marketing collateral. Naming is available too."
    },
    {
      "question": "How long does a brand identity take?",
      "answer": "Typically 4–6 weeks: brief, three concept routes, refinement through two revision rounds, the full system, then delivery of master files and guidelines."
    },
    {
      "question": "How many logo concepts will I see?",
      "answer": "Three logo and identity routes, each presented with its rationale. The chosen route is then refined through two revision rounds."
    },
    {
      "question": "What files do I receive?",
      "answer": "Master logo files in all required formats, brand guidelines and production-ready artwork for the applications included in your scope."
    }
  ],
  "/digital-experiences": [
    {
      "question": "What kinds of websites does UFAR build?",
      "answer": "Corporate websites, e-commerce stores, campaign landing pages, bilingual Arabic and English websites, and interface design for apps and platforms."
    },
    {
      "question": "How long does it take to build a website?",
      "answer": "Typically 4–10 weeks depending on scope: planning, wireframes, branded design, development and content entry, then testing and launch."
    },
    {
      "question": "Are the websites mobile-friendly and search-ready?",
      "answer": "Yes. Every site is designed for desktop and mobile, and launches with speed checks and SEO basics in place."
    },
    {
      "question": "Do you offer hosting and maintenance?",
      "answer": "Yes. Hosting, security, backups, monitoring and small changes are available as a monthly service."
    }
  ],
  "/content-brand-storytelling": [
    {
      "question": "Do you write in Arabic and English?",
      "answer": "Yes. We write in English and Arabic and adapt content between the two languages."
    },
    {
      "question": "What content can UFAR write?",
      "answer": "Content strategy and editorial plans, brand narratives and campaign messages, website and company profile copy, video and ad scripts, and social media copy."
    },
    {
      "question": "How long does a content project take?",
      "answer": "Typically 2–4 weeks: interviews and material review, editorial planning, writing, then two rounds of edits and a final proof."
    },
    {
      "question": "How many revisions are included?",
      "answer": "Two rounds of revisions are included per deliverable."
    }
  ],
  "/media-production": [
    {
      "question": "What media production services does UFAR offer?",
      "answer": "Brand and corporate films, commercials for social and digital, event coverage, executive interviews, short-form reels, motion graphics, drone footage, and brand, product, property, architecture and hospitality photography."
    },
    {
      "question": "How is video production priced?",
      "answer": "Media production is quoted per project once we receive your brief, because scope, shoot days, crew and locations set the price."
    },
    {
      "question": "What is the production process?",
      "answer": "Treatment and storyboard for approval, pre-production (crew, locations, casting, schedule), the shoot, post-production (editing, colour grading, sound and motion graphics), then delivery in every format you need."
    },
    {
      "question": "How long does a production take?",
      "answer": "Typically 2–6 weeks from treatment to final delivery, depending on the number of shoot days and deliverables."
    }
  ],
  "/social-media-community": [
    {
      "question": "What is included in social media management?",
      "answer": "Strategy and channel setup, monthly content calendars, designed posts, channel management and moderation, reels editing, community management seven days a week, and a monthly performance report."
    },
    {
      "question": "Is there a minimum contract?",
      "answer": "Monthly services run for a minimum of three months, then continue month to month."
    },
    {
      "question": "How do I approve content?",
      "answer": "Each month starts with a content calendar for your approval before anything is published."
    },
    {
      "question": "How is performance reported?",
      "answer": "You receive a monthly report with results and the adjustments planned for the next month."
    }
  ],
  "/campaigns-performance": [
    {
      "question": "Which advertising platforms does UFAR manage?",
      "answer": "Meta (Facebook and Instagram), Google, TikTok and LinkedIn."
    },
    {
      "question": "What does media planning include?",
      "answer": "Audience and targeting, channel mix, budget allocation, a flighting schedule, KPIs and forecasts, presented for your approval before launch."
    },
    {
      "question": "How is paid media management priced?",
      "answer": "Management is priced as a percentage of monthly ad spend. The ad budget itself is paid directly to the platforms."
    },
    {
      "question": "Do you offer SEO?",
      "answer": "Yes. SEO is available as a monthly service covering technical fixes, on-page optimisation, articles and a monthly report."
    }
  ]
};

/** Ready-to-use Next.js metadata for a route. */
export function getPageMetadata(route: PageRoute): Metadata {
  const p = pages[route];
  return {
    metadataBase: new URL(SITE_URL),
    title: p.title,
    description: p.description,
    keywords: p.keywords,
    alternates: p.alternates,
    robots: p.robots,
    openGraph: p.openGraph,
    twitter: p.twitter,
    authors: [{ name: site.name, url: SITE_URL }],
    other: { "geo.region": "EG", "geo.placename": "Egypt" },
  };
}

/** schema.org JSON-LD for a route — render inside <script type="application/ld+json">. */
export const jsonLd: Record<PageRoute, object> = {
  "/": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/#webpage",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions | Creative & Digital Agency in Egypt",
        "description": "Creative and digital agency in Egypt: marketing strategy, branding, websites, content, video production, social media and paid campaigns. Part of UFAR Group.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-home.jpg"
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What is UFAR Digital Solutions?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals."
            }
          },
          {
            "@type": "Question",
            "name": "Where is UFAR Digital Solutions based?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "UFAR Digital Solutions works from Egypt and is part of UFAR Group, alongside UFAR Real Estate Developments and UFAR Petroleum Services."
            }
          },
          {
            "@type": "Question",
            "name": "What services does UFAR offer?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Seven services: Positioning & Marketing Strategy, Brand Identity & Design, Digital Experiences (websites), Content & Brand Storytelling, Media Production, Social Media & Community, and Campaigns & Performance. Each can be used on its own or together."
            }
          },
          {
            "@type": "Question",
            "name": "How does UFAR price its work?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Every proposal is priced line by line, with no fixed packages, so you only pay for the work your business needs. Media production is quoted per project once we receive your brief."
            }
          },
          {
            "@type": "Question",
            "name": "How do I start a project with UFAR?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Send a message through the contact page or on WhatsApp +20 114 676 7446. We reply within two working days, agree the brief on a short call, then send a proposal."
            }
          }
        ]
      }
    ]
  },
  "/about": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "AboutPage",
        "@id": "https://ufar-eg.com/about.html#webpage",
        "url": "https://ufar-eg.com/about.html",
        "name": "About UFAR Digital Solutions | Part of UFAR Group",
        "description": "Meet UFAR Digital Solutions, the creative and digital agency of UFAR Group in Egypt: our story, vision, mission, brand promise and a word from Mr. Ibrahim.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-about.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "About UFAR Digital Solutions",
            "item": "https://ufar-eg.com/about.html"
          }
        ]
      }
    ]
  },
  "/services": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "CollectionPage",
        "@id": "https://ufar-eg.com/services.html#webpage",
        "url": "https://ufar-eg.com/services.html",
        "name": "Marketing, Branding & Digital Services in Egypt | UFAR",
        "description": "Seven areas of expertise, one vision: strategy, branding, websites, content, media production, social media and campaigns. UFAR's services in Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-services.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Marketing, Branding & Digital Services in Egypt",
            "item": "https://ufar-eg.com/services.html"
          }
        ]
      }
    ]
  },
  "/positioning-marketing-strategy": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/positioning-marketing-strategy.html#webpage",
        "url": "https://ufar-eg.com/positioning-marketing-strategy.html",
        "name": "Positioning & Marketing Strategy Agency in Egypt | UFAR",
        "description": "Brand audit, competitor benchmarking, positioning and a 90-day marketing plan in 3–5 weeks. Marketing strategy from UFAR Digital Solutions, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-strategy.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Positioning & Marketing Strategy",
            "item": "https://ufar-eg.com/positioning-marketing-strategy.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/positioning-marketing-strategy.html#service",
        "name": "Positioning & Marketing Strategy",
        "serviceType": "Positioning & Marketing Strategy",
        "description": "Brand audit, competitor benchmarking, positioning and a 90-day marketing plan in 3–5 weeks. Marketing strategy from UFAR Digital Solutions, Egypt.",
        "url": "https://ufar-eg.com/positioning-marketing-strategy.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What does Positioning & Marketing Strategy include?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "A brand experience audit of up to five touchpoints, benchmarking against three to five competitors, audience profiles and buying journey, positioning and value proposition, brand story and key messages, a marketing strategy with channels, priorities and KPIs, a 90-day action plan, and a strategy workshop with a final presentation."
            }
          },
          {
            "@type": "Question",
            "name": "How long does a marketing strategy take?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Typically 3–5 weeks, in five stages: kick-off and audit, benchmarking, audience definition, positioning, and the final strategy with a 90-day action plan."
            }
          },
          {
            "@type": "Question",
            "name": "Who is this service for?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Businesses launching something new, established brands that need a clearer direction, and companies preparing for growth. It is also the recommended starting point if you are not sure which service you need."
            }
          },
          {
            "@type": "Question",
            "name": "How is the strategy priced?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "It is priced as one complete service rather than separate items. Contact us for a proposal based on your business and scope."
            }
          }
        ]
      }
    ]
  },
  "/brand-identity-design": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/brand-identity-design.html#webpage",
        "url": "https://ufar-eg.com/brand-identity-design.html",
        "name": "Brand Identity & Logo Design Agency in Egypt | UFAR",
        "description": "Logo design, visual identity systems, brand guidelines, company profiles and packaging in 4–6 weeks. Brand identity design by UFAR Digital Solutions, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-identity.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Brand Identity & Design",
            "item": "https://ufar-eg.com/brand-identity-design.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/brand-identity-design.html#service",
        "name": "Brand Identity & Design",
        "serviceType": "Brand Identity & Design",
        "description": "Logo design, visual identity systems, brand guidelines, company profiles and packaging in 4–6 weeks. Brand identity design by UFAR Digital Solutions, Egypt.",
        "url": "https://ufar-eg.com/brand-identity-design.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What does brand identity design include?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Logo development, a visual identity system (colour, typography, graphic language), brand guidelines, stationery, company profiles, sales presentations, packaging and marketing collateral. Naming is available too."
            }
          },
          {
            "@type": "Question",
            "name": "How long does a brand identity take?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Typically 4–6 weeks: brief, three concept routes, refinement through two revision rounds, the full system, then delivery of master files and guidelines."
            }
          },
          {
            "@type": "Question",
            "name": "How many logo concepts will I see?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Three logo and identity routes, each presented with its rationale. The chosen route is then refined through two revision rounds."
            }
          },
          {
            "@type": "Question",
            "name": "What files do I receive?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Master logo files in all required formats, brand guidelines and production-ready artwork for the applications included in your scope."
            }
          }
        ]
      }
    ]
  },
  "/digital-experiences": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/digital-experiences.html#webpage",
        "url": "https://ufar-eg.com/digital-experiences.html",
        "name": "Website Design & Development Company in Egypt | UFAR",
        "description": "Corporate websites, e-commerce stores, landing pages and bilingual Arabic–English sites, designed and built in 4–10 weeks by UFAR Digital Solutions, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-digital.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Digital Experiences",
            "item": "https://ufar-eg.com/digital-experiences.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/digital-experiences.html#service",
        "name": "Digital Experiences",
        "serviceType": "Digital Experiences",
        "description": "Corporate websites, e-commerce stores, landing pages and bilingual Arabic–English sites, designed and built in 4–10 weeks by UFAR Digital Solutions, Egypt.",
        "url": "https://ufar-eg.com/digital-experiences.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What kinds of websites does UFAR build?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Corporate websites, e-commerce stores, campaign landing pages, bilingual Arabic and English websites, and interface design for apps and platforms."
            }
          },
          {
            "@type": "Question",
            "name": "How long does it take to build a website?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Typically 4–10 weeks depending on scope: planning, wireframes, branded design, development and content entry, then testing and launch."
            }
          },
          {
            "@type": "Question",
            "name": "Are the websites mobile-friendly and search-ready?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes. Every site is designed for desktop and mobile, and launches with speed checks and SEO basics in place."
            }
          },
          {
            "@type": "Question",
            "name": "Do you offer hosting and maintenance?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes. Hosting, security, backups, monitoring and small changes are available as a monthly service."
            }
          }
        ]
      }
    ]
  },
  "/content-brand-storytelling": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/content-brand-storytelling.html#webpage",
        "url": "https://ufar-eg.com/content-brand-storytelling.html",
        "name": "Content Writing & Brand Storytelling in Egypt | UFAR",
        "description": "Content strategy, website and company profile copy, scripts and social copy in Arabic and English. Brand storytelling by UFAR Digital Solutions, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-content.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Content & Brand Storytelling",
            "item": "https://ufar-eg.com/content-brand-storytelling.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/content-brand-storytelling.html#service",
        "name": "Content & Brand Storytelling",
        "serviceType": "Content & Brand Storytelling",
        "description": "Content strategy, website and company profile copy, scripts and social copy in Arabic and English. Brand storytelling by UFAR Digital Solutions, Egypt.",
        "url": "https://ufar-eg.com/content-brand-storytelling.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "Do you write in Arabic and English?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes. We write in English and Arabic and adapt content between the two languages."
            }
          },
          {
            "@type": "Question",
            "name": "What content can UFAR write?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Content strategy and editorial plans, brand narratives and campaign messages, website and company profile copy, video and ad scripts, and social media copy."
            }
          },
          {
            "@type": "Question",
            "name": "How long does a content project take?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Typically 2–4 weeks: interviews and material review, editorial planning, writing, then two rounds of edits and a final proof."
            }
          },
          {
            "@type": "Question",
            "name": "How many revisions are included?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Two rounds of revisions are included per deliverable."
            }
          }
        ]
      }
    ]
  },
  "/media-production": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/media-production.html#webpage",
        "url": "https://ufar-eg.com/media-production.html",
        "name": "Video Production & Photography Company in Egypt | UFAR",
        "description": "Brand films, commercials, event coverage, reels, product and architecture photography, editing and motion graphics. Media production by UFAR, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-media.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Media Production",
            "item": "https://ufar-eg.com/media-production.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/media-production.html#service",
        "name": "Media Production",
        "serviceType": "Media Production",
        "description": "Brand films, commercials, event coverage, reels, product and architecture photography, editing and motion graphics. Media production by UFAR, Egypt.",
        "url": "https://ufar-eg.com/media-production.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What media production services does UFAR offer?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Brand and corporate films, commercials for social and digital, event coverage, executive interviews, short-form reels, motion graphics, drone footage, and brand, product, property, architecture and hospitality photography."
            }
          },
          {
            "@type": "Question",
            "name": "How is video production priced?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Media production is quoted per project once we receive your brief, because scope, shoot days, crew and locations set the price."
            }
          },
          {
            "@type": "Question",
            "name": "What is the production process?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Treatment and storyboard for approval, pre-production (crew, locations, casting, schedule), the shoot, post-production (editing, colour grading, sound and motion graphics), then delivery in every format you need."
            }
          },
          {
            "@type": "Question",
            "name": "How long does a production take?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Typically 2–6 weeks from treatment to final delivery, depending on the number of shoot days and deliverables."
            }
          }
        ]
      }
    ]
  },
  "/social-media-community": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/social-media-community.html#webpage",
        "url": "https://ufar-eg.com/social-media-community.html",
        "name": "Social Media Management Agency in Egypt | UFAR",
        "description": "Social media strategy, content calendars, designed posts, reels, moderation, community management and monthly reports. Social media management by UFAR, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-social.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Social Media & Community",
            "item": "https://ufar-eg.com/social-media-community.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/social-media-community.html#service",
        "name": "Social Media & Community",
        "serviceType": "Social Media & Community",
        "description": "Social media strategy, content calendars, designed posts, reels, moderation, community management and monthly reports. Social media management by UFAR, Egypt.",
        "url": "https://ufar-eg.com/social-media-community.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What is included in social media management?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Strategy and channel setup, monthly content calendars, designed posts, channel management and moderation, reels editing, community management seven days a week, and a monthly performance report."
            }
          },
          {
            "@type": "Question",
            "name": "Is there a minimum contract?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Monthly services run for a minimum of three months, then continue month to month."
            }
          },
          {
            "@type": "Question",
            "name": "How do I approve content?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Each month starts with a content calendar for your approval before anything is published."
            }
          },
          {
            "@type": "Question",
            "name": "How is performance reported?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "You receive a monthly report with results and the adjustments planned for the next month."
            }
          }
        ]
      }
    ]
  },
  "/campaigns-performance": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "WebPage",
        "@id": "https://ufar-eg.com/campaigns-performance.html#webpage",
        "url": "https://ufar-eg.com/campaigns-performance.html",
        "name": "Performance Marketing & Paid Ads Agency in Egypt | UFAR",
        "description": "Media planning, tracking, paid campaigns on Meta, Google, TikTok and LinkedIn, plus SEO, managed against agreed goals. Performance marketing by UFAR, Egypt.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-campaigns.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Services",
            "item": "https://ufar-eg.com/services.html"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "Campaigns & Performance",
            "item": "https://ufar-eg.com/campaigns-performance.html"
          }
        ]
      },
      {
        "@type": "Service",
        "@id": "https://ufar-eg.com/campaigns-performance.html#service",
        "name": "Campaigns & Performance",
        "serviceType": "Campaigns & Performance",
        "description": "Media planning, tracking, paid campaigns on Meta, Google, TikTok and LinkedIn, plus SEO, managed against agreed goals. Performance marketing by UFAR, Egypt.",
        "url": "https://ufar-eg.com/campaigns-performance.html",
        "provider": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "availableLanguage": [
          "English",
          "Arabic"
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "Which advertising platforms does UFAR manage?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Meta (Facebook and Instagram), Google, TikTok and LinkedIn."
            }
          },
          {
            "@type": "Question",
            "name": "What does media planning include?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Audience and targeting, channel mix, budget allocation, a flighting schedule, KPIs and forecasts, presented for your approval before launch."
            }
          },
          {
            "@type": "Question",
            "name": "How is paid media management priced?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Management is priced as a percentage of monthly ad spend. The ad budget itself is paid directly to the platforms."
            }
          },
          {
            "@type": "Question",
            "name": "Do you offer SEO?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes. SEO is available as a monthly service covering technical fixes, on-page optimisation, articles and a monthly report."
            }
          }
        ]
      }
    ]
  },
  "/clients": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "CollectionPage",
        "@id": "https://ufar-eg.com/clients.html#webpage",
        "url": "https://ufar-eg.com/clients.html",
        "name": "Our Clients | UFAR Digital Solutions",
        "description": "Brands that work with UFAR Digital Solutions, including Kempinski, Vodafone, Banque Misr, Ezz Elarab Automotive Group, Resala and UFAR Group companies.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-clients.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Our Clients",
            "item": "https://ufar-eg.com/clients.html"
          }
        ]
      }
    ]
  },
  "/contact": {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": [
          "Organization",
          "ProfessionalService"
        ],
        "@id": "https://ufar-eg.com/#organization",
        "name": "UFAR Digital Solutions",
        "alternateName": [
          "UFAR",
          "يوفار للحلول الرقمية"
        ],
        "slogan": "United For A Reason",
        "description": "UFAR Digital Solutions is a creative and digital agency in Egypt and part of UFAR Group. It brings positioning and marketing strategy, brand identity, websites, content, media production, social media and performance campaigns together around each client's business goals.",
        "url": "https://ufar-eg.com/",
        "logo": "https://ufar-eg.com/assets/images/logo.png",
        "image": "https://ufar-eg.com/assets/images/og/og-home.jpg",
        "telephone": "+201146767446",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "EG"
        },
        "areaServed": {
          "@type": "Country",
          "name": "Egypt"
        },
        "parentOrganization": {
          "@type": "Organization",
          "name": "UFAR Group"
        },
        "contactPoint": {
          "@type": "ContactPoint",
          "contactType": "sales",
          "telephone": "+201146767446",
          "url": "https://ufar-eg.com/contact.html",
          "availableLanguage": [
            "English",
            "Arabic"
          ]
        },
        "knowsAbout": [
          "Marketing strategy",
          "Brand positioning",
          "Brand identity design",
          "Logo design",
          "Website design",
          "Web development",
          "Content writing",
          "Video production",
          "Photography",
          "Social media management",
          "Performance marketing",
          "Media planning",
          "SEO"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "UFAR Digital Solutions services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Positioning & Marketing Strategy",
                "url": "https://ufar-eg.com/positioning-marketing-strategy.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Brand Identity & Design",
                "url": "https://ufar-eg.com/brand-identity-design.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Experiences",
                "url": "https://ufar-eg.com/digital-experiences.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Content & Brand Storytelling",
                "url": "https://ufar-eg.com/content-brand-storytelling.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Media Production",
                "url": "https://ufar-eg.com/media-production.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Social Media & Community",
                "url": "https://ufar-eg.com/social-media-community.html"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Campaigns & Performance",
                "url": "https://ufar-eg.com/campaigns-performance.html"
              }
            }
          ]
        }
      },
      {
        "@type": "WebSite",
        "@id": "https://ufar-eg.com/#website",
        "url": "https://ufar-eg.com/",
        "name": "UFAR Digital Solutions",
        "inLanguage": "en",
        "publisher": {
          "@id": "https://ufar-eg.com/#organization"
        }
      },
      {
        "@type": "ContactPage",
        "@id": "https://ufar-eg.com/contact.html#webpage",
        "url": "https://ufar-eg.com/contact.html",
        "name": "Contact UFAR Digital Solutions | Start a Project",
        "description": "Tell us what you are building. Use the contact form or WhatsApp +20 114 676 7446 — we reply within two working days with the questions that shape the brief.",
        "inLanguage": "en",
        "isPartOf": {
          "@id": "https://ufar-eg.com/#website"
        },
        "about": {
          "@id": "https://ufar-eg.com/#organization"
        },
        "dateModified": "2026-11-23",
        "primaryImageOfPage": "https://ufar-eg.com/assets/images/og/og-contact.jpg"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://ufar-eg.com/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Contact UFAR Digital Solutions",
            "item": "https://ufar-eg.com/contact.html"
          }
        ]
      }
    ]
  }
};
