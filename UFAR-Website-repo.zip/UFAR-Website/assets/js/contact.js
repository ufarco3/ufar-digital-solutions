// Contact form: front-end only. Connect the submit to your backend or form service
// so messages reach ufarco3@gmail.com, then keep the thank-you state below.
(function(){
  var form=document.getElementById('contactForm'),wrap=document.getElementById('formWrap'),thanks=document.getElementById('thanks'),reset=document.getElementById('resetForm');
  if(!form)return;
  form.addEventListener('submit',function(e){
    e.preventDefault();
    // TODO: send new FormData(form) to the server here.
    wrap.hidden=true;thanks.hidden=false;
  });
  if(reset)reset.addEventListener('click',function(){form.reset();thanks.hidden=true;wrap.hidden=false;});
})();
