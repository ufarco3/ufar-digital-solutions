# UFAR Digital Solutions — Website (design handoff)

Static HTML/CSS build of the approved website design. Open `index.html` in a browser to view; all pages are linked.

## Pages (sitemap)
| File | Page |
|---|---|
| index.html | Home |
| about.html | About us (story, vision & mission, UFAR Group, message from Mr. Ibrahim) |
| services.html | Services overview |
| positioning-marketing-strategy.html | Service: Positioning & Marketing Strategy |
| brand-identity-design.html | Service: Brand Identity & Design |
| digital-experiences.html | Service: Digital Experiences |
| content-brand-storytelling.html | Service: Content & Brand Storytelling |
| media-production.html | Service: Media Production |
| social-media-community.html | Service: Social Media & Community |
| campaigns-performance.html | Service: Campaigns & Performance |
| clients.html | Our clients |
| contact.html | Contact form and details |

## Brand
- **Font:** Manrope (Google Fonts), weights 400–800
- **Colours:** Navy `#101D35` · Deep navy `#0B1528` · Panel navy `#16264A` · Gold `#C5A46D` · Dark gold `#8C6A2F` · Off-white `#F5F3EE` · Body text `#3A4660`
- **Logo:** `assets/images/logo.png` — always shown on a light (off-white) plaque on dark backgrounds, per the brand guidelines.

## Structure
- `assets/css/style.css` — shared styles (layout classes, typography, header, footer, responsive breakpoints at 1000px and 760px).
- `assets/images/` — all photography, logo, signature and client logos.
- `assets/js/contact.js` — contact form front-end behaviour.
- Section-level styling is inline in each page, exactly as designed. Move it into the stylesheet or your framework's components as you prefer.

## To do for development
1. **Contact form** (`contact.html`): connect the form to a backend or form service so submissions are emailed to **ufarco3@gmail.com**. Field names: name, company, email, phone, services (multiple), timing, msg. The thank-you state is already handled in `contact.js`.
2. **Header and footer** are repeated in every page — turn them into shared includes/components.
3. **WhatsApp links** use `https://wa.me/201146767446`.
4. Add analytics (GA4 / Meta Pixel), favicon set, Open Graph images and per-page meta descriptions.
5. Optimise images (WebP, responsive `srcset`) before launch.
6. Optional: Arabic version (RTL) using the same layout.

## SEO & AI search (GEO)
Already in place:
- Unique meta title, description and keywords (English + Arabic) on every page — see `seo-metadata.ts` (typed, Next.js Metadata API ready, with FAQ content and JSON-LD) and `seo-metadata.csv` (spreadsheet view).
- Canonical URLs, Open Graph and Twitter cards with 1200×630 share images (`assets/images/og/`).
- Schema.org JSON-LD on every page: Organization/ProfessionalService, WebSite, WebPage, BreadcrumbList, Service (service pages) and FAQPage (home and service pages).
- `robots.txt` (allows Google, Bing and AI crawlers such as GPTBot, OAI-SearchBot, ClaudeBot, PerplexityBot), `sitemap.xml` (with images), `llms.txt` (summary for AI answer engines), `site.webmanifest`.
- Question-shaped FAQ sections with direct answers, a consistent one-line company description, descriptive image alt text, lazy-loaded images, skip link and `<main>` landmark.

After launch:
1. Upload to https://ufar-eg.com (all URLs assume this domain; change `BASE` if different) and serve over HTTPS.
2. Submit `sitemap.xml` in Google Search Console and Bing Webmaster Tools.
3. Make sure your host/CDN (e.g. Cloudflare bot protection) does not block the AI crawlers listed in `robots.txt`.
4. Add the office street address and opening hours to the JSON-LD `address` once confirmed, and create/claim a Google Business Profile with the same name, phone and website.
5. Build an Arabic version (RTL) with `hreflang="ar"` links — many searches in Egypt are in Arabic.
6. Compress images to WebP and keep page speed (Core Web Vitals) green.


- Email: ufarco3@gmail.com
- WhatsApp: +20 114 676 7446
- Website: ufar-eg.com
